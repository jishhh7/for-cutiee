
function openEnvelope() {
  document.querySelector('.flap').style.transform = 'rotateX(-180deg)';
  document.querySelector('.letter').style.transform = 'translateY(0)';
  document.getElementById('bgm').play();
}
